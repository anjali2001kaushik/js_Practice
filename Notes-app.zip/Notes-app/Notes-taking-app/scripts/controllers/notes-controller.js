  //Controller (I/O)+Events+talk to service
  
  import { notesOperations } from "../services/notes-operations.js";
  window.addEventListener('load',init);
  function init(){
   showCounts();
   bindEvents();
   disableButton();
  }
  const disableButton=()=>{
   document.querySelector('#delete').disabled=true;
  }
  const enableButton=()=>{
   // document.querySelector('#delete').removeAttribute('disabled');
   document.querySelector('#delete').disabled=false

  }
  function bindEvents(){

   document.querySelector('#add').addEventListener('click',addNote)
   document.querySelector('#delete').addEventListener('click',deleteNote)
  }
  function showCounts(){
   notesOperations.marktotal()>0?enableButton():disableButton();
   document.querySelector('#total').innerText=notesOperations.total();
   document.querySelector('#marktotal').innerText=notesOperations.marktotal();
   document.querySelector('#unmarktotal').innerText=notesOperations.unmarktotal();
   
  }
   function addNote(){
    //read id,title,desc,date of completion,importance
    //Dom
    // const id=document.querySelector('#id').value;
    // const title=document.querySelector('#title').value;
    // const desc=document.querySelector('#id').value;
    const fields=['id','title','desc','cdate','importance'];
    const noteObject={};//Object Literal
    for(let field of fields){
       noteObject[field]= document.querySelector(`#${field}`).value.trim();
    }
   //  console.log(noteObject)
    notesOperations.add(noteObject);
    printNote(noteObject);
    showCounts();

    }
    function deleteNote(){
      notesOperations.remove();
      printNotes();
      showCounts();
    }
    function printNotes(){
      const tbody=document.querySelector('#notes');
      tbody.innerHTML="";//erases the content
      const notes=notesOperations.getAllNotes();
      notes.forEach(printNote);
      showCounts();
    }
  
    function printNote(noteObject){
      
        const tbody=document.querySelector('#notes')
       const row= tbody.insertRow();//<tr>
       for(let key in noteObject){
         if(key!='isMarked'){
            const td=row.insertCell();//<td>
            td.innerText=noteObject[key];
         }
       }
      //  const tdForOperations=row.insertCell();
      //  tdForOperations.appendChild(printIcon());
      const td=row.insertCell();
       td.appendChild(printIcon('trash',toggleDelete,noteObject.id)); 
       td.appendChild(printIcon('user-pen',edit,noteObject.id));
       
    }
    function printIcon(myClassName='trash',callBackfn,noteId){
      // <i class="fa-solid fa-trash"></i>
      // <i class="fa-solid fa-user-pen"></i>
         const iTag=document.createElement('i');//To create dynamic ta
         iTag.setAttribute('note-id',noteId);
         iTag.className=`fa-solid fa-${myClassName} me-4 hand`;
         iTag.addEventListener('click',callBackfn)
         return iTag;
   }
    function toggleDelete(){
      console.log('toggle mark' ,this);
       const id=this.getAttribute('note-id');//this iTag ka hai
       notesOperations.toggleMark(id);
       const currentIcon=this;
      const tr=currentIcon.parentNode.parentNode;
      // tr.className='table-danger'; isse toggle nhi hota  
      tr.classList.toggle('table-danger');
      showCounts();
      // if(notesOperations.marktotal()>0){
      //    enableButton();
      //    console.log(notesOperations.marktotal())
      //    // document.querySelector('#delete').setAttribute('disabled',false);
      // }
      

    }
    function edit(){
      
    }