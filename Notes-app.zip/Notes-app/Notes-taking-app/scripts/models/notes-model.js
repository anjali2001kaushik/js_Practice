//ES6
// export class Note{
    class Note{
    // constructor(id=0,title="",desc="",cdate="",importance=""){
    //     this.id=id;
    //     this.title=title;
    //     this.desc=desc;
    //     this.cdate=cdate;
    //     this.importance=importance;
    //     this.isMarked=false;
    // }
    constructor(noteObject){
        for(let key in noteObject){
            this[key]=noteObject[key];
        }
        this.isMarked=false;
    }
    toggleMark(){
        this.isMarked=!this.isMarked;
    }
}
export default Note;