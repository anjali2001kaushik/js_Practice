//CRUD
import Note from "../models/notes-model.js"
export const notesOperations={
    notes:[],
    add(noteObject){
        const note=new Note(noteObject);
        // for(let key in note){
        //     note[key]=noteObject[key];
        // }
        // console.log('NOT',note)
        this.notes.push(note);//ye this  notesOperations jka hai
    },
    getAllNotes(){
        return this.notes;
    },
    total(){
        return this.notes.length;
    },
    marktotal(){
      return  this.notes.filter(note=>note.isMarked).length;
    },
    unmarktotal(){
        return this.total()-this.marktotal();
    },
    remove(){
        this.notes=this.notes.filter(note=>!note.isMarked)
    },
    searchById(id){
        return this.notes.find(note=>note.id===id);

    },
    sort(){

    },
    update(){

    },
    load(){

    },
    save(){

    },
    toggleMark(id){
        this.searchById(id).toggleMark();
        const noteObject=this.searchById(id)//this notesOperations ka hai
        // if(noteObject){
        //     noteObject.isMarked=!noteObject.isMarked;
        // }
       
    }
}